export default async function handler(req, res) {
  if (req.method!== 'POST') {
    return res.status(405).json({ status: false, message: "Method not allowed" });
  }

  const { email, amount, product } = req.body;
  const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET; // put in Vercel env
  const RESEND_KEY = process.env.RESEND_KEY; // put in Vercel env

  try {
    // 1. Create payment link
    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${PAYSTACK_SECRET}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, amount })
    });

    const data = await response.json();

    if(data.status === true){
      const payment_link = data.data.authorization_url;
      const amountNaira = (amount / 100).toLocaleString('en-NG');

      // 2. Send branded HTML email
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${RESEND_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          from: "Your Brand <onboarding@resend.dev>", // change Your Brand
          to: [email],
          subject: `Payment Link for ${product}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 10px;">
              <h2 style="color: #0a66c2; text-align: center;">Complete Your Payment</h2>
              <p>Hello,</p>
              <p>Thank you for choosing our <b>${product}</b> service.</p>

              <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0;"><b>Service:</b> ${product}</p>
                <p style="margin: 5px 0 0 0;"><b>Amount:</b> ₦${amountNaira}</p>
              </div>

              <p>Click the button below to complete your payment securely:</p>

              <a href="${payment_link}" style="display: inline-block; background: #0a66c2; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; margin: 10px 0;">
                Pay Now ₦${amountNaira}
              </a>

              <p style="font-size: 12px; color: #777; margin-top: 20px;">
                If the button doesn't work, copy this link: <br>
                <a href="${payment_link}">${payment_link}</a>
              </p>

              <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 20px 0;">
              <p style="font-size: 12px; color: #999; text-align: center;">
                This link expires in 24 hours. <br>
                © 2026 ITag. All rights reserved.
              </p>
            </div>
          `
        })
      });

      return res.status(200).json({ status: true, message: "Payment link sent to " + email });
    } else {
      return res.status(400).json({ status: false, message: data.message });
    }

  } catch (error) {
    return res.status(500).json({ status: false, message: error.message });
  }
}